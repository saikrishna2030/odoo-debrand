## Module <odoo-debrand>

#### 17.10.2019
#### Version 13.0.1.0.0
#### ADD
Initial Commit for odoo-debrand

#### 17.10.2019
#### Version 13.0.1.3.3
#### UPDT
License section restored.
